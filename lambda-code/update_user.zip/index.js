import { S3 } from "@aws-sdk/client-s3";
import bcrypt from "bcryptjs";
import { decryptBody, encryptResponse } from "./aes.js";

const s3 = new S3({ region: "ap-south-1" });
const BUCKET_NAME = "weconnect-scheduling-data-test";

export const handler = async (event) => {
  try {
    console.log("📥 Received event:", JSON.stringify(event, null, 2));

    // 🔐 Decrypt body
    let decryptedData;
    try {
      decryptedData = decryptBody(event.body);
    } catch (err) {
      console.error("❌ AES decryption failed:", err);
      return errorResponse(400, "Invalid or malformed encrypted request");
    }

    const { id, updatedUser } = decryptedData;

    const oldFirstName = updatedUser.oldFirstName?.trim();
    const oldLastName = updatedUser.oldLastName?.trim();
    const newFirstName = updatedUser.firstName?.trim();
    const newLastName = updatedUser.lastName?.trim();

    if (!newFirstName || !newLastName) {
      return errorResponse(400, "First name and last name are required");
    }

    const formatFileName = (first, last) =>
      `${first.replace(/\s+/g, ".")}.${last.replace(/\s+/g, ".")}.json`;

    const oldKey = oldFirstName && oldLastName
      ? `user-info/${formatFileName(oldFirstName, oldLastName)}`
      : null;

    const newKey = `user-info/${formatFileName(newFirstName, newLastName)}`;

    let existingData = {};
    if (oldKey) {
      try {
        const { Body } = await s3.getObject({ Bucket: BUCKET_NAME, Key: oldKey });
        existingData = JSON.parse(await Body.transformToString("utf-8"));
      } catch (err) {
        if (err.name !== "NoSuchKey") {
          console.error("❌ Failed to fetch existing user file:", err);
          return errorResponse(500, "Error fetching existing user");
        }
      }
    }

    // ✅ Handle password update securely
    let passwordToStore = existingData.password;
    if (updatedUser.password && updatedUser.confirmPassword) {
      if (updatedUser.password !== updatedUser.confirmPassword) {
        return errorResponse(400, "Passwords do not match");
      }
      passwordToStore = await bcrypt.hash(updatedUser.password, 10);
    }

    // 🔁 Merge updated fields
    const mergedData = {
      ...existingData,
      ...updatedUser,
      password: passwordToStore,
    };

    delete mergedData.confirmPassword;
    delete mergedData.oldFirstName;
    delete mergedData.oldLastName;

    // 📝 Save new file
    await s3.putObject({
      Bucket: BUCKET_NAME,
      Key: newKey,
      Body: JSON.stringify(mergedData, null, 2),
      ContentType: "application/json"
    });

    // 🧹 Delete old file if renamed
    if (oldKey && oldKey !== newKey) {
      await s3.deleteObject({ Bucket: BUCKET_NAME, Key: oldKey });
    }

    console.log(`✅ Updated user data: ${newKey}`);
    return successResponse({ message: "User updated successfully", updatedUser: mergedData });

  } catch (err) {
    console.error("❌ Unexpected error:", err);
    return errorResponse(500, "Failed to update user");
  }
};

// Helpers
const successResponse = (body) => ({
  statusCode: 200,
  headers: corsHeaders(),
  body: encryptResponse(body),
});

const errorResponse = (statusCode, message) => ({
  statusCode,
  headers: corsHeaders(),
  body: encryptResponse({ error: message }),
});

const corsHeaders = () => ({
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "OPTIONS,POST,PUT,GET,DELETE",
  "Access-Control-Allow-Headers": "Content-Type,Authorization"
});
