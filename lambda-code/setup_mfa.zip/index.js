// setup-mfa/index.js
import { S3, HeadObjectCommand } from "@aws-sdk/client-s3";
import speakeasy from "speakeasy";
import QRCode from "qrcode";
import { decryptBody, encryptResponse } from "./aes.js";

const s3 = new S3({ region: "ap-south-1" });
const bucketName = "weconnect-scheduling-data-test";
const mfaPrefix = "MFA/";

export const handler = async (event) => {
  console.log("📥 [START] Received event");

  let decrypted;
  try {
    decrypted = decryptBody(event.body);
    console.log("🔓 Decrypted Payload:", decrypted);
  } catch (err) {
    console.error("❌ Failed to decrypt:", err);
    return generateResponse(400, { error: "Invalid encrypted payload" });
  }

  const { username, displayName } = decrypted;

  if (!username || !displayName) {
    return generateResponse(400, { error: "Username and displayName are required." });
  }

  const normalized = username.trim().replace(/\s+/g, ".");
  const mfaKey = `${mfaPrefix}${normalized}.mfa.json`;

  try {
    await s3.send(new HeadObjectCommand({ Bucket: bucketName, Key: mfaKey }));
    return generateResponse(400, { error: "MFA already set up." });
  } catch (err) {
    if (err.name === "NotFound" || err.$metadata?.httpStatusCode === 404) {
      console.log("✅ MFA not set. Proceeding.");
    } else {
      console.error("❌ Error checking MFA file:", err);
      return generateResponse(500, { error: "Failed to check MFA." });
    }
  }

  const formattedLabel = `WeConnect Scheduler (${displayName})`;
  const secret = speakeasy.generateSecret({ name: formattedLabel });
  const qrCodeURL = await QRCode.toDataURL(secret.otpauth_url);

  const mfaData = {
    secret: secret.base32,
    otpauth_url: secret.otpauth_url,
  };

  await s3.putObject({
    Bucket: bucketName,
    Key: mfaKey,
    Body: JSON.stringify(mfaData),
    ContentType: "application/json",
  });

  console.log("✅ MFA setup complete.");
  return generateResponse(200, { qrCodeURL });
};

const generateResponse = (statusCode, body) => ({
  statusCode,
  headers: { "Content-Type": "application/json" },
  body: encryptResponse(body),
});
