// verify-mfa/index.js
import { S3 } from "@aws-sdk/client-s3";
import speakeasy from "speakeasy";
import { decryptBody, encryptResponse } from "./aes.js";

const s3 = new S3({ region: "ap-south-1" });
const bucketName = "weconnect-scheduling-data-test";
const mfaPrefix = "MFA/";

export const handler = async (event) => {
  console.info("🟢 [START] MFA Verify Event");

  let decrypted;
  try {
    decrypted = decryptBody(event.body);
    console.info("🔓 Decrypted MFA Payload:", decrypted);
  } catch (err) {
    console.error("❌ Failed to decrypt MFA request:", err);
    return generateResponse(400, { error: "Invalid encrypted payload" });
  }

  const { username, code } = decrypted;

  if (!username || !code) {
    return generateResponse(400, { error: "Username and MFA code required." });
  }

  const normalized = username.trim().replace(/\s+/g, ".");
  const mfaKey = `${mfaPrefix}${normalized}.mfa.json`;

  let mfaData;
  try {
    const data = await s3.getObject({ Bucket: bucketName, Key: mfaKey });
    mfaData = JSON.parse(await streamToString(data.Body));
  } catch (err) {
    return err.name === "NoSuchKey"
      ? generateResponse(404, { error: "MFA setup not found. Please set up MFA first." })
      : generateResponse(500, { error: "Internal server error." });
  }

  const verified = speakeasy.totp.verify({
    secret: mfaData.secret,
    encoding: "base32",
    token: code,
    window: 1,
  });

  if (!verified) {
    return generateResponse(401, { error: "Invalid MFA code." });
  }

  return generateResponse(200, { message: "MFA verified successfully." });
};

const generateResponse = (statusCode, body) => ({
  statusCode,
  headers: { "Content-Type": "application/json" },
  body: encryptResponse(body),
});

const streamToString = async (stream) => {
  const chunks = [];
  for await (const chunk of stream) chunks.push(chunk);
  return Buffer.concat(chunks).toString("utf-8");
};
