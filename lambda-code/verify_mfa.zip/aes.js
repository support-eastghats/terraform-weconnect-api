// aes.js
import crypto from "crypto";

const key = Buffer.from("a64fd3358d673b70b103ba5772e28811da247b38a70261c4554c71359bf8d040", "hex");

export function decryptBody(eventBody) {
  if (!eventBody) throw new Error("Missing event body");

  const parsed = typeof eventBody === "string" ? JSON.parse(eventBody) : eventBody;

  if (!parsed.iv || !parsed.content) {
    throw new Error("Invalid payload structure");
  }

  const decipher = crypto.createDecipheriv("aes-256-cbc", key, Buffer.from(parsed.iv, "hex"));
  let decrypted = decipher.update(parsed.content, "base64", "utf8");
  decrypted += decipher.final("utf8");

  return JSON.parse(decrypted);
}

export function encryptResponse(data) {
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv("aes-256-cbc", key, iv);
  let encrypted = cipher.update(JSON.stringify(data), "utf8", "base64");
  encrypted += cipher.final("base64");

  return JSON.stringify({
    iv: iv.toString("hex"),
    content: encrypted,
  });
}
