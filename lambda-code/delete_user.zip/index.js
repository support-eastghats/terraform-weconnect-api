import { S3 } from "@aws-sdk/client-s3";
import { decryptBody, encryptResponse } from "./aes.js";

const s3 = new S3({ region: "ap-south-1" });
const bucketName = "weconnect-scheduling-data-test";
const userPrefix = "user-info/";
const mfaPrefix = "MFA/";

export const handler = async (event) => {
  try {
    const body = decryptBody(event.body);
    const fullName = body.fullName;

    if (!fullName) {
      return formatResponse(400, { error: "Missing fullName in request body" });
    }

    const userKey = `${userPrefix}${fullName}.json`;
    const mfaKey = `${mfaPrefix}${fullName}.mfa.json`;

    // Delete user file
    await s3.deleteObject({ Bucket: bucketName, Key: userKey });
    console.log(`✅ Deleted user file: ${userKey}`);

    // Try deleting MFA file (ignore if not found)
    try {
      await s3.deleteObject({ Bucket: bucketName, Key: mfaKey });
      console.log(`✅ Deleted MFA file: ${mfaKey}`);
    } catch (mfaErr) {
      console.warn(`⚠️ MFA file not found or already deleted: ${mfaKey}`);
    }

    return formatResponse(200, encryptResponse({ message: "User and MFA deleted successfully." }));

  } catch (err) {
    console.error("❌ Delete error:", err);
    return formatResponse(500, encryptResponse({ error: "Failed to delete user or MFA", details: err.message }));
  }
};

const formatResponse = (statusCode, body) => ({
  statusCode,
  headers: {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "OPTIONS,POST",
    "Access-Control-Allow-Headers": "Content-Type,Authorization"
  },
  body: typeof body === "string" ? body : JSON.stringify(body),
});
