import { S3 } from "@aws-sdk/client-s3";
import { decryptBody, encryptResponse } from "./aes.js";
import crypto from "crypto";

const s3 = new S3({ region: "ap-south-1" });
const BUCKET_NAME = "weconnect-scheduling-data-test";
const AES_KEY = Buffer.from("a64fd3358d673b70b103ba5772e28811da247b38a70261c4554c71359bf8d040", "hex");

export const handler = async (event) => {
  console.info("📥 [START] Get User by ID");

  try {
    if (!event?.body) return response(400, { error: "Missing request body" });

    const decrypted = decryptBody(event.body);
    console.info("🔓 Decrypted Payload:", decrypted);

    const { id } = decrypted;
    if (!id) return response(400, { error: "Missing user ID" });

    const { Contents } = await s3.listObjectsV2({ Bucket: BUCKET_NAME, Prefix: "user-info/" });
    let userData = null;

    for (const file of Contents) {
      const { Body } = await s3.getObject({ Bucket: BUCKET_NAME, Key: file.Key });
      const raw = await Body.transformToString("utf-8");
      const user = JSON.parse(raw);

      if (user.id === id) {
        // 🔓 Decrypt the password if it's stored encrypted
        if (user.password && typeof user.password === "object" && user.password.iv && user.password.content) {
          const decryptedPassword = decryptPassword(user.password.iv, user.password.content);
          user.password = decryptedPassword;
        }
        userData = user;
        break;
      }
    }

    if (!userData) return response(404, { error: "User not found" });
    return response(200, userData);

  } catch (err) {
    console.error("❌ Error:", err);
    return response(500, { error: "Internal server error" });
  }
};

function decryptPassword(ivHex, contentB64) {
  const iv = Buffer.from(ivHex, "hex");
  const encrypted = Buffer.from(contentB64, "base64");
  const decipher = crypto.createDecipheriv("aes-256-cbc", AES_KEY, iv);
  let decrypted = decipher.update(encrypted, "base64", "utf8");
  decrypted += decipher.final("utf8");
  return decrypted;
}

const response = (statusCode, body) => ({
  statusCode,
  headers: { "Content-Type": "application/json" },
  body: encryptResponse(body),
});
