// ✅ Secure list-users Lambda with AES encryption
import { S3 } from "@aws-sdk/client-s3";
import { encryptResponse } from "./aes.js";

const s3 = new S3({ region: "ap-south-1" });
const BUCKET_NAME = "weconnect-scheduling-data-test";
const PREFIX = "user-info/";

export const handler = async () => {
  try {
    const { Contents } = await s3.listObjectsV2({ Bucket: BUCKET_NAME, Prefix: PREFIX });

    if (!Contents || Contents.length === 0) {
      console.warn("\ud83d\udcec No user files found in user-info/");
      return formatEncryptedResponse(200, []);
    }

    console.log(`\ud83d\udce6 Found ${Contents.length} user file(s)`);

    const userPromises = Contents.map(async (file) => {
      try {
        const { Body } = await s3.getObject({ Bucket: BUCKET_NAME, Key: file.Key });
        if (!Body) return null;
        const content = await streamToString(Body);
        return JSON.parse(content);
      } catch (err) {
        console.error(`\u274c Failed to read ${file.Key}:`, err);
        return null;
      }
    });

    const users = (await Promise.all(userPromises)).filter(Boolean);
    users.sort((a, b) => (a.firstName || "").localeCompare(b.firstName || ""));

    return formatEncryptedResponse(200, users);
  } catch (err) {
    console.error("\u274c Error listing users:", err);
    return formatEncryptedResponse(500, { error: "Failed to retrieve users" });
  }
};

const streamToString = async (stream) => {
  const chunks = [];
  for await (const chunk of stream) chunks.push(chunk);
  return Buffer.concat(chunks).toString("utf-8");
};

const formatEncryptedResponse = (statusCode, body) => ({
  statusCode,
  headers: {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "OPTIONS,GET,POST,PUT,DELETE",
    "Access-Control-Allow-Headers": "Content-Type,Authorization"
  },
  body: encryptResponse(body)
});
