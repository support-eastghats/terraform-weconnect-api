// get-user-mfa/index.js
import { S3 } from "@aws-sdk/client-s3";
import { decryptBody, encryptResponse } from "./aes.js";

const s3 = new S3({ region: "ap-south-1" });
const BUCKET_NAME = "weconnect-scheduling-data-test";
const PREFIX = "MFA/";

export const handler = async (event) => {
  try {
    const decrypted = decryptBody(event.body);
    const { username } = decrypted;

    if (!username) return format(400, { error: "Missing username" });

    const fileKey = `${PREFIX}${username}.mfa.json`;

    const head = await s3.headObject({ Bucket: BUCKET_NAME, Key: fileKey });

    return format(200, {
      mfaName: fileKey.split("/").pop(),
      createdAt: head.LastModified,
    });

  } catch (err) {
    if (err.name === "NotFound") {
      return format(404, { error: "MFA not found" });
    }

    console.error("❌ Error fetching MFA:", err);
    return format(500, { error: "Internal error" });
  }
};

const format = (statusCode, body) => ({
  statusCode,
  headers: {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
  },
  body: encryptResponse(body),
});
