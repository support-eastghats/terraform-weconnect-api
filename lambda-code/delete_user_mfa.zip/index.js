// delete-user-mfa/index.js
import { S3 } from "@aws-sdk/client-s3";
import { decryptBody, encryptResponse } from "./aes.js";

const s3 = new S3({ region: "ap-south-1" });
const BUCKET_NAME = "weconnect-scheduling-data-test";
const PREFIX = "MFA/";

export const handler = async (event) => {
  try {
    const { username } = decryptBody(event.body);
    if (!username) return response(400, { error: "Missing username" });

    const Key = `${PREFIX}${username}.mfa.json`;
    await s3.deleteObject({ Bucket: BUCKET_NAME, Key });

    return response(200, { message: "MFA deleted" });
  } catch (err) {
    console.error("❌ Error deleting MFA:", err);
    return response(500, { error: "Failed to delete MFA" });
  }
};

const response = (statusCode, body) => ({
  statusCode,
  headers: {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
  },
  body: encryptResponse(body),
});
