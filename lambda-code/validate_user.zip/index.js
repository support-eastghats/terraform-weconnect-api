import { S3 } from "@aws-sdk/client-s3";
import bcrypt from "bcryptjs";
import { decryptBody, encryptResponse } from "./aes.js";

const s3 = new S3({ region: "ap-south-1" });
const bucketName = "weconnect-scheduling-data-test";
const userInfoPrefix = "user-info/";
const mfaPrefix = "MFA/";

export const handler = async (event) => {
  console.info("🟢 [START] Event Received");

  if (!event?.body) {
    console.error("❌ Missing event body");
    return response(400, { error: "Missing request body" });
  }

  let decrypted;
  try {
    decrypted = decryptBody(event.body);
    console.info("🔓 Decrypted Payload:", decrypted);
  } catch (err) {
    console.error("❌ Failed to decrypt:", err);
    return response(400, { error: "Invalid encrypted payload" });
  }

  const { username, password } = decrypted;

  if (!username || !password) {
    console.warn("⚠️ Missing username or password");
    return response(400, { error: "Username and password are required." });
  }

  const normalizedUsername = username.trim().replace(/\s+/g, ".");
  const fileKey = `${userInfoPrefix}${normalizedUsername}.json`;

  let userData;
  try {
    const data = await s3.getObject({ Bucket: bucketName, Key: fileKey });
    userData = JSON.parse(await streamToString(data.Body));
  } catch (err) {
    console.error("❌ S3 GetObject error:", err);
    return response(404, { error: "User not found." });
  }

  try {
    const passwordMatch = await bcrypt.compare(password, userData.password.trim());
    if (!passwordMatch) {
      console.warn(`❌ Invalid password for user: ${normalizedUsername}`);
      return response(401, { error: "Invalid credentials." });
    }
  } catch (err) {
    console.error("❌ bcrypt.compare error:", err);
    return response(500, { error: "Password verification failed." });
  }

  let requiresMFA = false;
  try {
    const mfaKey = `${mfaPrefix}${normalizedUsername}.mfa.json`;
    await s3.headObject({ Bucket: bucketName, Key: mfaKey });
    requiresMFA = true;
  } catch (err) {
    if (err.name !== "NotFound" && err.$metadata?.httpStatusCode !== 404) {
      return response(500, { error: "Error checking MFA status." });
    }
  }

  const responseBody = {
    requiresMFA,
    setupMFA: !requiresMFA,
    user: {
      firstName: userData.firstName,
      lastName: userData.lastName,
      email: userData.email,
      group: userData.group,
      designation: userData.designation,
      permissionSet: userData.permissionSet,
    }
  };

  return response(200, responseBody);
};

const response = (statusCode, body) => ({
  statusCode,
  headers: { "Content-Type": "application/json" },
  body: encryptResponse(body)
});

const streamToString = async (stream) => {
  const chunks = [];
  for await (const chunk of stream) chunks.push(chunk);
  return Buffer.concat(chunks).toString("utf-8");
};
